import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import RegistrationForm from "./RegistrationForm";
import UrlShortener from "./UrlShortener";
import Statistics from "./Statistics";
import { AppBar, Toolbar, Button } from "@mui/material";

function App() {
  return (
    <Router>
      <AppBar position="static">
        <Toolbar>
          <Button color="inherit" component={Link} to="/">Register</Button>
          <Button color="inherit" component={Link} to="/shortener">Shorten</Button>
          <Button color="inherit" component={Link} to="/stats">Statistics</Button>
        </Toolbar>
      </AppBar>

      <Routes>
        <Route path="/" element={<RegistrationForm />} />
        <Route path="/shortener" element={<UrlShortener />} />
        <Route path="/stats" element={<Statistics />} />
      </Routes>
    </Router>
  );
}

export default App;


