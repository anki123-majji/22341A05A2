import { useEffect, useState } from "react";
import { Box, Typography, Paper, Table, TableHead, TableRow, TableCell, TableBody, CircularProgress } from "@mui/material";

function Statistics() {
  const [stats, setStats] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const response = await fetch("https://api.example.com/stats", {
          headers: { "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJNYXBDbGFpbXMiOnsiYXVkIjoiaHR0cDovLzIwLjI0NC41Ni4xNDQvZXZhbHVhdGlvbi1zZXJ2aWNlIiwiZW1haWwiOiIyMjM0MWEwNWEyQGdtcml0LmVkdS5pbiIsImV4cCI6MTc1NzM5Njg3OCwiaWF0IjoxNzU3Mzk1OTc4LCJpc3MiOiJBZmZvcmQgTWVkaWNhbCBUZWNobG9naWVzIFByaXZhdGUgTGltaXRlZCIsImp0aSI6IjI2YTVmZGExLWQxNjctNGJiYi04ZjhmLWIyMmYxNzAzNjJkNiIsImxvY2FsZSI6ImVuLUlOIiwibmFtZSI6Im1hamppIGFua2l0aGEiLCJzdWIiOiJjOTBiZGIyZC05NzAwLTQwNTItOTg2NC1iZTQ1ZmM2M2E5YmQifSwiZW1haWwiOiIyMjM0MWEwNWEyQGdtcml0LmVkdS5pbiIsIm5hbWUiOiJtYWpqaSBhbmtpdGhhIiwicm9sbE5vIjoiMjIzNDFhMDVhMiIsImFjY2Vzc0NvZGUiOiJlZXRoTmUiLCJjbGllbnRJRCI6ImM5MGJkYjJkLTk3MDAtNDA1Mi05ODY0LWJlNDVmYzYzYTliZCIsImNsaWVudFNlY3JldCI6IlJ1QWdUamt1SHRCcWdWQkUifQ.E46s1-IBfOU16VJdvYTlLbMTtB4uhc31aiujEBDelPg"
 }
        });

        if (!response.ok) throw new Error("Failed to fetch stats");
        const result = await response.json();
        setStats(result.data || []);
      } catch (err) {
        console.error(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  return (
    <Box display="flex" justifyContent="center" alignItems="center" minHeight="100vh" bgcolor="#f5f5f5">
      <Paper elevation={3} sx={{ p: 4, width: 600 }}>
        <Typography variant="h5" align="center" gutterBottom>URL Statistics</Typography>

        {loading ? (
          <CircularProgress />
        ) : (
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Short URL</TableCell>
                <TableCell>Long URL</TableCell>
                <TableCell>Clicks</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {stats.map((row, index) => (
                <TableRow key={index}>
                  <TableCell>{row.shortUrl}</TableCell>
                  <TableCell>{row.longUrl}</TableCell>
                  <TableCell>{row.clicks}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </Paper>
    </Box>
  );
}

export default Statistics;
