import { useState } from "react";
import { TextField, Button, Box, Typography, Paper, CircularProgress } from "@mui/material";

function UrlShortener() {
  const [url, setUrl] = useState("");
  const [shortUrl, setShortUrl] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setShortUrl("");

    try {
      const response = await fetch("https://api.example.com/shorten", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJNYXBDbGFpbXMiOnsiYXVkIjoiaHR0cDovLzIwLjI0NC41Ni4xNDQvZXZhbHVhdGlvbi1zZXJ2aWNlIiwiZW1haWwiOiIyMjM0MWEwNWEyQGdtcml0LmVkdS5pbiIsImV4cCI6MTc1NzM5Njg3OCwiaWF0IjoxNzU3Mzk1OTc4LCJpc3MiOiJBZmZvcmQgTWVkaWNhbCBUZWNobG9naWVzIFByaXZhdGUgTGltaXRlZCIsImp0aSI6IjI2YTVmZGExLWQxNjctNGJiYi04ZjhmLWIyMmYxNzAzNjJkNiIsImxvY2FsZSI6ImVuLUlOIiwibmFtZSI6Im1hamppIGFua2l0aGEiLCJzdWIiOiJjOTBiZGIyZC05NzAwLTQwNTItOTg2NC1iZTQ1ZmM2M2E5YmQifSwiZW1haWwiOiIyMjM0MWEwNWEyQGdtcml0LmVkdS5pbiIsIm5hbWUiOiJtYWpqaSBhbmtpdGhhIiwicm9sbE5vIjoiMjIzNDFhMDVhMiIsImFjY2Vzc0NvZGUiOiJlZXRoTmUiLCJjbGllbnRJRCI6ImM5MGJkYjJkLTk3MDAtNDA1Mi05ODY0LWJlNDVmYzYzYTliZCIsImNsaWVudFNlY3JldCI6IlJ1QWdUamt1SHRCcWdWQkUifQ.E46s1-IBfOU16VJdvYTlLbMTtB4uhc31aiujEBDelPg"

        },
        body: JSON.stringify({ url }),
      });

      if (!response.ok) throw new Error("Failed to shorten URL");
      const result = await response.json();
      setShortUrl(result.shortUrl);
    } catch (err) {
      setShortUrl(`❌ Error: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box display="flex" justifyContent="center" alignItems="center" minHeight="100vh" bgcolor="#f5f5f5">
      <Paper elevation={3} sx={{ p: 4, width: 400 }}>
        <Typography variant="h5" align="center" gutterBottom>URL Shortener</Typography>

        <form onSubmit={handleSubmit}>
          <TextField fullWidth margin="normal" label="Enter Long URL" value={url} onChange={(e) => setUrl(e.target.value)} required />
          <Button type="submit" fullWidth variant="contained" sx={{ mt: 2 }} disabled={loading}>
            {loading ? <CircularProgress size={24} /> : "Shorten"}
          </Button>
        </form>

        {shortUrl && <Typography align="center" sx={{ mt: 2, wordBreak: "break-word" }}>{shortUrl}</Typography>}
      </Paper>
    </Box>
  );
}

export default UrlShortener;
